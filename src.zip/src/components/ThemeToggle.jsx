// import React, { useState, useEffect } from "react";

// const ThemeToggle = () => {
//   const [darkMode, setDarkMode] = useState(() => {
//     // Initialize from localStorage or system preference
//     if (typeof window !== "undefined") {
//       const saved = localStorage.getItem("theme");
//       if (saved) return saved === "dark";
//       return window.matchMedia("(prefers-color-scheme: dark)").matches;
//     }
//     return false;
//   });

//   useEffect(() => {
//     const root = document.documentElement;
//     if (darkMode) {
//       root.classList.add("dark");
//       localStorage.setItem("theme", "dark");
//     } else {
//       root.classList.remove("dark");
//       localStorage.setItem("theme", "light");
//     }
//   }, [darkMode]);

//   return (
//     <button
//       onClick={() => setDarkMode((prev) => !prev)}
//       className="p-2 rounded bg-gray-200 text-black dark:bg-gray-800 dark:text-white"
//     >
//       {darkMode ? "Light Mode" : "Dark Mode"}
//     </button>
//   );
// };

// export default ThemeToggle;


import { useEffect, useState } from "react";

const ThemeToggle = () => {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    // Toggle dark class directly on body
    if (isDark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [isDark]);

  return (
    <button
      onClick={() => setIsDark(prev => !prev)}
      className="p-2 rounded bg-gray-300 dark:bg-gray-700 text-black dark:text-white"
    >
      {isDark ? "☀ Light Mode" : "🌙 Dark Mode"}
    </button>
  );
};

export default ThemeToggle;
