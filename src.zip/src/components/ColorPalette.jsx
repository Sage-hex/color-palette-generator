import React from "react";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { motion } from "framer-motion";

const ColorPalette = ({ colors }) => {
  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4 p-4">
      {Object.entries(colors).map(([scheme, palette]) => (
        <div key={scheme} className="flex flex-col items-center">
          <h3 className="text-lg font-bold mb-2">{scheme}</h3>
          {palette.map((color, index) => (
            <motion.div
              key={index}
              className="w-full h-20 rounded shadow-lg mb-2 relative"
              style={{ backgroundColor: color }}
              whileHover={{ scale: 1.05 }}
            >
              <CopyToClipboard text={color}>
                <button className="absolute inset-0 w-full h-full text-white opacity-0 hover:opacity-100 transition-opacity flex justify-center items-center">
                  Copy
                </button>
              </CopyToClipboard>
            </motion.div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default ColorPalette;