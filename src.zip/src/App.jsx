// import React, { useState } from "react";
// import ColorPicker from "./components/ColorPicker";
// import ColorPalette from "./components/ColorPalette";
// import ThemeToggle from "./components/ThemeToggle";

// function App() {
//   const [colors, setColors] = useState({});

//   return (
//     <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
//       <div className="container mx-auto p-4">
//         <h1 className="text-3xl font-bold text-center my-4">Color Palette Generator</h1>
//         <ThemeToggle />
//         <ColorPicker onGenerate={setColors} />
//         <ColorPalette colors={colors} />
//       </div>
//     </div>
//   );
// }

// export default App;



import React from "react";
import ThemeToggle from "./components/ThemeToggle";
import ColorPicker from "./components/ColorPicker";
import ColorPalette from "./components/ColorPalette";

function App() {
  return (
    <div className="min-h-screen transition-colors duration-300 bg-white text-black dark:bg-black dark:text-white">
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold text-center mb-6">
          Color Palette Generator
        </h1>
        <ThemeToggle />
        <ColorPicker onGenerate={() => {}} />
        <ColorPalette colors={{}} />
      </div>
    </div>
  );
}

export default App;
