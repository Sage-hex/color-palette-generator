import chroma from "chroma-js";

export const generateColors = (baseColor) => {
  const color = chroma(baseColor);

  return {
    complementary: [color.hex(), color.set("hsl.h", "+180").hex()],
    analogous: [
      color.set("hsl.h", "-30").hex(),
      color.hex(),
      color.set("hsl.h", "+30").hex(),
    ],
    triadic: [
      color.set("hsl.h", "+120").hex(),
      color.hex(),
      color.set("hsl.h", "-120").hex(),
    ],
    monochromatic: [
      color.brighten(1).hex(),
      color.hex(),
      color.darken(1).hex(),
    ],
  };
};